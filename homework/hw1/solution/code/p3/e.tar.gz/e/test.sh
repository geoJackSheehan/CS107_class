#!/usr/bin/env bash
# 1.
# find . -type f ! -perm -o=rw | wc -l # includes hidden file: 4 (wrong)
find . -type f ! -path "*/.*" ! -perm -o=rw | wc -l # excludes hidden file: 3
# 2.
find . -maxdepth 1 -name "[!.]*" \( -type f -or -type d \) ! -perm -o=rw | wc -l
ls -ld * | grep '^.......rw.' -v | wc -l # using regex
